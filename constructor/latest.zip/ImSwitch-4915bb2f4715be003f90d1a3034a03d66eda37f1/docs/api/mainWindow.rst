**********
mainWindow
**********

.. class:: mainWindow

   These functions are available in the mainWindow object. 

   .. method:: setCurrentModule(self, moduleId: str) -> None

      Sets the currently displayed module to the module with the
      specified ID (e.g. "imcontrol"). 

