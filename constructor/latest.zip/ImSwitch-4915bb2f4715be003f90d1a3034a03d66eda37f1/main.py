from imswitch.__main__ import main

main()