This directory contains example setups for the hardware control module.
