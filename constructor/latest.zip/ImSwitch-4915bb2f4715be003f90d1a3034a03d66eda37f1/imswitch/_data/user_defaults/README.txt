This directory should contain example files that the user can learn from, or use to try out the
program and its capabilities. Its contents are automatically copied to the user files directory when
the program starts (except for readme.txt files, and when a file with the same path already exists
in the user files).
