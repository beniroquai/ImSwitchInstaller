This directory contains example scripts for ImSwitch's scripting module. Please note that the
scripts must be executed through the scripting module and cannot be run outside it.
