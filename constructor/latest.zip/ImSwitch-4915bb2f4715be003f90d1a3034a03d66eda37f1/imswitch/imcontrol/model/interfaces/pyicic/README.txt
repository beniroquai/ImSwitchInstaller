The contents of this folder originate from https://github.com/morefigs/py-ic-imaging-control and are
licensed under the MIT License.
